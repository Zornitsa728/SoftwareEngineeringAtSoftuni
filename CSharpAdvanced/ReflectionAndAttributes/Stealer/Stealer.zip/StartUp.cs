﻿namespace Stealer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Spy spy = new Spy();
            string[] fieldsName = { "username", "password" };
            string result = spy.StealFieldInfo("Stealer.Hacker", fieldsName);
            Console.WriteLine(result);
        }
    }
}