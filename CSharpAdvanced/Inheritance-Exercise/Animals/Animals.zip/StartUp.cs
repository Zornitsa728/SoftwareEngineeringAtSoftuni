﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Animals
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            List<Animal> listOfAnimals = new List<Animal>();
            string input = string.Empty;

            while ((input = Console.ReadLine()) != "Beast!")
            {
                string animalType = input.Trim();
                string[] animalInfo = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);

                if (animalInfo.Length != 3)
                {
                    if (animalType != "Kitten" && animalType != "Tomcat")
                    {
                        Console.WriteLine("Invalid input!");
                        continue;
                    }
                }

                string name = animalInfo[0];
                int age = int.Parse(animalInfo[1]);

                switch (animalType)
                {
                    case "Dog":
                        try
                        {
                            Dog dog = new Dog(name, age, animalInfo[2]);
                            listOfAnimals.Add(dog);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;
                    case "Frog":
                        try
                        {
                            Frog frog = new Frog(name, age, animalInfo[2]);
                            listOfAnimals.Add(frog);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;
                    case "Cat":
                        try
                        {
                            Cat cat = new Cat(name, age, animalInfo[2]);
                            listOfAnimals.Add(cat);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;
                    case "Kitten":
                        try
                        {
                            Kitten kitten = new Kitten(name, age);
                            listOfAnimals.Add(kitten);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;
                    case "Tomcat":
                        try
                        {
                            Tomcat tomcat = new Tomcat(name, age);
                            listOfAnimals.Add(tomcat);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;
                }

            }

            foreach (Animal animal in listOfAnimals)
            {
                Console.WriteLine(animal.ToString());
            }
        }
    }
}
