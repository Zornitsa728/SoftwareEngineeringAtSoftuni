﻿
using System.Threading.Channels;

namespace CustomLinkedList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
           

        }
    }
}