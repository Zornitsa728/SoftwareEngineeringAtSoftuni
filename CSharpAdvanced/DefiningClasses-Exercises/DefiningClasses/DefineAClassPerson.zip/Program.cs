﻿using DefiningClasses;
using System;
public class StartUp
{
    public static void Main(string[] args)
    {
        Person person = new Person();
        person.Name = "Test";
        person.Age = 30;
    }
}
