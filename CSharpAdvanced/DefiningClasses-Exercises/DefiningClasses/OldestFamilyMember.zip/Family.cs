﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefiningClasses
{
    public class Family
    {
        private List<Person> people = new List<Person>();
        public List<Person> People { get { return this.people; } set { this.people = value; } }

        public void AddMembers(Person member)
        {
            this.People.Add(member);
        }

        public Person GetOldestMember()
        {
            People = People.OrderByDescending(x => x.Age).ToList();
            Person oldestPerson = new Person(People[0].Name, People[0].Age);

            //int oldest = int.MinValue;

            //foreach (Person person in People) 
            //{
            //    if (oldest<person.Age)
            //    {
            //        oldest = person.Age;
            //        oldestPerson = person;
            //    }
            //}

            return oldestPerson;
        }
    }
}
