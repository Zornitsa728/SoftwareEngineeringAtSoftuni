﻿using DefiningClasses;
using System;
public class StartUp
{
    public static void Main(string[] args)
    {
        int peopleCount = int.Parse(Console.ReadLine());
        Family family = new();

        for (int currPerson = 0; currPerson < peopleCount; currPerson++)
        {
            string[] personProps = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            Person person = new Person(personProps[0], int.Parse(personProps[1]));

            family.AddMembers(person);
        }

        Person oldestMember = family.GetOldestMember();

        Console.WriteLine($"{oldestMember.Name} {oldestMember.Age}");
    }
}
