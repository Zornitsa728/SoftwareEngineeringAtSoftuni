﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BorderControl.Interfaces
{
    public interface IIdentifiable
    {
        public string Id { get;}
    }
}
