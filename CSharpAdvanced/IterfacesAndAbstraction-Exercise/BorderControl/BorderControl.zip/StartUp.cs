﻿using BorderControl.Interfaces;
using BorderControl.Models;

namespace BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<IIdentifiable> ids = new();

            string input = string.Empty;

            while ((input = Console.ReadLine()) != "End")
            {
                string[] tokens = input
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries);

                if (tokens.Length == 3)
                {
                    IIdentifiable human = new Citizen(tokens[0], int.Parse(tokens[1]), tokens[2]);
                    ids.Add(human);
                }
                else
                {
                    IIdentifiable robot = new Robot(tokens[0], tokens[1]);
                    ids.Add(robot);
                }
            }

            string fakeId = Console.ReadLine();
            int lastFakeDigitsLength = fakeId.ToString().Length;

            foreach (var id in ids)
            {
                if (id.Id.EndsWith(fakeId))
                {
                    Console.WriteLine(id.Id);
                }
            }
        }
    }
}