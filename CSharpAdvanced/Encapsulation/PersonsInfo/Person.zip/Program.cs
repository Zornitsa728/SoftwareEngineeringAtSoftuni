﻿namespace PersonsInfo
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int lines = int.Parse(Console.ReadLine());
            List<Person> people = new List<Person>();

            for (int i = 0; i < lines; i++)
            {
                string[] tokens = Console.ReadLine()
                    .Split(" ",StringSplitOptions.RemoveEmptyEntries);

                string firstName = tokens[0];
                string lastName = tokens[1];
                int age = int.Parse(tokens[2]);

                people.Add(new Person(firstName, lastName, age));
            }

            foreach (var person in people.OrderBy(p => p.FirstName).ThenBy(p => p.Age)) 
            {
                Console.WriteLine(person);
            }
        }
    }
}