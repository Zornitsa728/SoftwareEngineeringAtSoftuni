﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vehicles.Models.Interfaces;

namespace Vehicles.Models
{
    public class Vehicle : IVehicle
    {
        private double increasedConsumtion;
        public Vehicle(double fuelQuantity, double consumtionPerKm, double increasedConsumtion)
        {
            FuelQuantity = fuelQuantity;
            ConsumtionPerKm = consumtionPerKm;
            this.increasedConsumtion = increasedConsumtion;
        }

        public double FuelQuantity { get; private set; }

        public double ConsumtionPerKm { get; private set; }

        public string Drive(double distance)
        {
            double neededFuel = distance * (ConsumtionPerKm + increasedConsumtion);

            if (FuelQuantity - neededFuel < 0)
            {
                throw new ArgumentException($"{GetType().Name} needs refueling");
            }

            FuelQuantity -= neededFuel;
            return $"{GetType().Name} travelled {distance} km";
        }

        public virtual void Refuel(double liters)
        {
            FuelQuantity += liters;
        }
        public override string ToString()
        {
            return $"{GetType().Name}: {FuelQuantity:f2}";
        }
    }
}
