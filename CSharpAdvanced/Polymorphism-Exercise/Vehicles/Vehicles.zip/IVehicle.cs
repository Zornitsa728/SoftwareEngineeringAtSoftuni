﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    public interface IVehicle
    {
        public double FuelQuantity { get; }

        public double ConsumtionPerKm { get; }

        public bool Drive(double distance);

        public void Refuel(double liters);
    }
}
