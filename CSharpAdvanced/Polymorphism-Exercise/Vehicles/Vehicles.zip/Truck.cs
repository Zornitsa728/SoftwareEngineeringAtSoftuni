﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    public class Truck : IVehicle
    {
        private const double IncreasedConsumption = 1.6;

        public Truck(double fuelQuantity, double consumtionPerKm)
        {
            FuelQuantity = fuelQuantity;
            ConsumtionPerKm = consumtionPerKm;
        }

        public double FuelQuantity { get; private set; }

        public double ConsumtionPerKm { get; private set; }

        public bool Drive(double distance)
        {
            double neededFuel = distance * (ConsumtionPerKm + IncreasedConsumption);

            if (FuelQuantity - neededFuel >= 0)
            {
                FuelQuantity -= neededFuel;
                return true;
            }
            else
            {
                return false;
            }
        }

        public void Refuel(double liters)
        {
            FuelQuantity += liters - (liters * 0.05);
        }

        public override string ToString()
        {
            return $"{GetType().Name}: {FuelQuantity:f2}";
        }
    }
}
