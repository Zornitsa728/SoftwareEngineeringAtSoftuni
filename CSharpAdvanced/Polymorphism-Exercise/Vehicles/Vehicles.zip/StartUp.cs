﻿namespace Vehicles
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] carTokens = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);
            //Car car = new Car(double.Parse(carTokens[1]), double.Parse(carTokens[2]));
            IVehicle car = new Car(double.Parse(carTokens[1]), double.Parse(carTokens[2]));

            string[] truckTokens = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);
            //Truck truck = new Truck(double.Parse(truckTokens[1]), double.Parse(truckTokens[2]));
            IVehicle truck = new Truck(double.Parse(truckTokens[1]), double.Parse(truckTokens[2]));

            int count = int.Parse(Console.ReadLine());
            

            for (int i = 0; i < count; i++)
            {
                string[] cmdArgs = Console.ReadLine()
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries);

                if (cmdArgs[0] == "Drive")
                {
                    if (cmdArgs[1] == "Car")
                    {
                        DriveDistance(car, double.Parse(cmdArgs[2]));
                    }
                    else
                    {
                        DriveDistance(truck, double.Parse(cmdArgs[2]));
                    }
                }
                else
                {
                    if (cmdArgs[1] == "Car")
                    {
                        car.Refuel(double.Parse(cmdArgs[2]));
                    }
                    else
                    {
                        truck.Refuel(double.Parse(cmdArgs[2]));
                    }
                }
            }

            Console.WriteLine(car.ToString());
            Console.WriteLine(truck.ToString());

            static void DriveDistance(IVehicle vehicle, double distance)
            {
                if (vehicle.Drive(distance))
                {
                    Console.WriteLine($"{vehicle.GetType().Name} travelled {distance} km");
                }
                else
                {
                    Console.WriteLine($"{vehicle.GetType().Name} needs refueling");
                }
            }
        }
    }
}