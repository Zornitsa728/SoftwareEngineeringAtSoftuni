﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    public class Car : IVehicle
    {
        private const double IncreasedConsumption = 0.9;
        public Car(double fuelQuantity, double consumtionPerKm)
        {
            FuelQuantity = fuelQuantity;
            ConsumtionPerKm = consumtionPerKm;
        }

        public double FuelQuantity { get; private set; }

        public double ConsumtionPerKm { get; private set; }

        public bool Drive(double distance)
        {
            double neededFuel = distance * (ConsumtionPerKm + IncreasedConsumption);

            if (FuelQuantity - neededFuel >= 0)
            {
                FuelQuantity -= neededFuel;
                return true;
            }
            else
            {
                return false;
            }
        }

        public void Refuel(double liters)
        {
            FuelQuantity += liters;
        }

        public override string ToString()
        {
            return $"{GetType().Name}: {FuelQuantity:f2}";
        }
    }
}
