namespace Database.Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class DatabaseTests
    {
        [Test]
        public void When_ArrayIsNot16IntegersLong_ShouldThrownException()
        {
            Database database = new Database(new int[16]);

            Assert.Throws<InvalidOperationException>(() => { database.Add(1); });
        }

        [Test]
        public void When_AddingElement_ShouldBeAddAtTheNextFreeCell()
        {
            Database database = new Database(1, 2, 3, 4, 5);
            database.Add(6);
            int[] result = database.Fetch();

            Assert.AreEqual(6, result[5]);
        }

        [Test]
        public void When_RemoveElement_ShouldRemovingAtTheLastIndex()
        {
            Database database = new Database(1, 2, 3, 4, 5);

            database.Remove();
            int[] result = { 1, 2, 3, 4 };

            Assert.AreEqual(result, database.Fetch());
        }

        [Test]
        public void When_TryToRemoveFromAnEMptyDatabase_ShouldReturnAnException()
        {
            Database database = new Database();

            Assert.Throws<InvalidOperationException>(() => database.Remove());
        }

        [Test]
        public void When_CreatingAnInstance_Constructor_ShouldTakeOnlyIntegersAsAnArray()
        {
            Database database = new Database(1, 2, 3, 4, 5);

            Assert.AreEqual(5, database.Count);

        }

        [Test]
        public void When_Fetch_ShouldReturnAnArray()
        {
            int[] numbers = { 1, 2, 3, 4, 5 };
            Database database = new Database(numbers);

            Assert.AreEqual(numbers, database.Fetch());
        }
    }
}
